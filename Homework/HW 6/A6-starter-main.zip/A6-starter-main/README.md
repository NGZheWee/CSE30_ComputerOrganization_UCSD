# Fill out fields below before turning in your assignment

- Cite Assistance (TA or Tutor is fine if you don't remember their name):
- Estimated Hours spent on assignment:
- Acknowledge that you adhered to our Academic Integrity Pledge by typing your name.
Name:
